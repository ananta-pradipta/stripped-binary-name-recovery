#!/usr/bin/env python3
"""
LLM Baseline: Predict function names from Ghidra-decompiled pseudo-C code
using StarCoder2-3B on Wulver (course_gpu, A100 10g MIG).

Usage (called by run_starcoder.sbatch):
    python3 llm_predict.py \
        --decompiled ~/starcoder_eval_v2/decompiled \
        --ground-truth ~/starcoder_eval_v2/repo/data/cross_project/ground_truth/ground_truth.json \
        --output ~/starcoder_eval_v2/predictions.json
"""
import os
import sys
import json
import argparse
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


# ============ Wulver paths (defaults) ============
DECOMPILED_DIR = os.path.expanduser("~/starcoder_eval_v2/decompiled")
GT_PATH        = os.path.expanduser("~/starcoder_eval_v2/repo/data/cross_project/ground_truth/ground_truth.json")
OUTPUT_PATH    = os.path.expanduser("~/starcoder_eval_v2/predictions.json")
MODEL_NAME     = "bigcode/starcoder2-3b"
# ==================================================


FEW_SHOT_EXAMPLES = """Below are examples of decompiled C functions and their original names:

Example 1:
```c
void FUN_00401230(int param_1) {
    int iVar1;
    sockaddr local_28;
    iVar1 = socket(2, 1, 0);
    memset(&local_28, 0, 0x10);
    local_28.sa_family = 2;
    local_28.sa_data._0_2_ = htons((short)param_1);
    local_28.sa_data._2_4_ = 0;
    bind(iVar1, &local_28, 0x10);
    listen(iVar1, 5);
    return;
}
```
Original function name: socket_init

Example 2:
```c
int FUN_004012a0(char *param_1) {
    FILE *pFVar1;
    char acStack_118[264];
    int local_10;
    pFVar1 = fopen(param_1, "r");
    if (pFVar1 == NULL) return -1;
    local_10 = 0;
    while (fgets(acStack_118, 0x100, pFVar1) != NULL) {
        local_10 = local_10 + 1;
    }
    fclose(pFVar1);
    return local_10;
}
```
Original function name: parse_config

Example 3:
```c
ulong FUN_00401400(uchar *param_1, ulong param_2) {
    ulong uVar1;
    uVar1 = 0;
    for (ulong i = 0; i < param_2; i++) {
        uVar1 = uVar1 + (ulong)param_1[i];
        uVar1 = uVar1 << 3 | uVar1 >> 0x3d;
        uVar1 = uVar1 ^ 0xa5a5a5a5;
    }
    return uVar1;
}
```
Original function name: compute_checksum
"""


def build_prompt(decompiled_code: str, few_shot: bool = True) -> str:
    max_code_len = 2000
    if len(decompiled_code) > max_code_len:
        decompiled_code = decompiled_code[:max_code_len] + "\n// ... (truncated)"

    if few_shot:
        prompt = FEW_SHOT_EXAMPLES + f"""
Now predict the original function name for this decompiled function:
```c
{decompiled_code}
```
Original function name:"""
    else:
        prompt = f"""What is the original function name for this decompiled C function?
```c
{decompiled_code}
```
Original function name:"""
    return prompt


def extract_prediction(generated_text: str) -> str:
    text = generated_text.strip()
    for sep in ['\n', '\r', '```', '//', '/*', '(', '{', ';', '"', "'"]:
        text = text.split(sep)[0]
    text = text.strip().strip('`').strip()
    if not text or len(text) > 100:
        return "unknown"
    text = text.strip('_') if text != '_' else text
    return text if text else "unknown"


def load_ground_truth(gt_path: str) -> tuple:
    with open(gt_path) as f:
        gt_data = json.load(f)

    lookup = {}
    for binary_key, binary_info in gt_data.items():
        functions = binary_info.get("functions", {})
        for addr, name in functions.items():
            addr_clean = addr.lower().lstrip('0') or '0'
            lookup[(binary_key, addr_clean)] = name
    return lookup, gt_data


def load_decompiled(decompiled_dir: str) -> dict:
    all_functions = {}
    for fname in sorted(os.listdir(decompiled_dir)):
        if not fname.endswith('.json'):
            continue
        fpath = os.path.join(decompiled_dir, fname)
        with open(fpath) as f:
            data = json.load(f)
        binary_key = fname.replace('.json', '')
        for suffix in ['_stripped', '_strip']:
            if binary_key.endswith(suffix):
                binary_key = binary_key[:-len(suffix)]
        all_functions[binary_key] = data
    return all_functions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--decompiled", default=DECOMPILED_DIR)
    parser.add_argument("--ground-truth", default=GT_PATH)
    parser.add_argument("--output", default=OUTPUT_PATH)
    parser.add_argument("--model", default=MODEL_NAME)
    parser.add_argument("--few-shot", action="store_true", default=True)
    parser.add_argument("--no-few-shot", dest="few_shot", action="store_false")
    parser.add_argument("--max-functions", type=int, default=None)
    args = parser.parse_args()

    # On MIG, CUDA_VISIBLE_DEVICES is set by SLURM — always use cuda:0
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    print(f"CUDA_VISIBLE_DEVICES: {os.environ.get('CUDA_VISIBLE_DEVICES', 'not set')}")
    print(f"Loading model: {args.model}")

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.float16,
        device_map={"": device},
        trust_remote_code=True
    )
    model.eval()

    if torch.cuda.is_available():
        print(f"Model loaded. GPU memory: {torch.cuda.memory_allocated() / 1e9:.1f} GB")

    gt_lookup, gt_data = load_ground_truth(args.ground_truth)
    decompiled = load_decompiled(args.decompiled)

    print(f"Ground truth: {len(gt_lookup)} functions across {len(gt_data)} binaries")
    print(f"Decompiled: {len(decompiled)} binaries")

    predictions = {}
    total = 0
    matched = 0
    skipped_no_gt = 0
    skipped_trivial = 0

    skip_names = {'_start', '_init', '_fini', '__libc_csu_init', '__libc_csu_fini',
                  '__do_global_dtors_aux', '_dl_relocate_static_pie', 'frame_dummy',
                  'register_tm_clones', 'deregister_tm_clones', '__libc_start_main',
                  'atexit', '__stack_chk_fail'}

    # Build per-binary GT address sets for base-offset detection
    gt_by_binary = {}
    for (bk, addr_c), name in gt_lookup.items():
        if bk not in gt_by_binary:
            gt_by_binary[bk] = {}
        gt_by_binary[bk][addr_c] = name

    def detect_base_offset(dec_addrs, gt_addrs_set):
        """Try common Ghidra base offsets to align addresses."""
        for offset in [0x0, 0x100000, 0x200000, 0x400000, 0x10000]:
            matches = 0
            for da in list(dec_addrs)[:50]:  # sample first 50
                try:
                    adjusted = hex(int(da, 16) - offset).lstrip('0x').lstrip('0') or '0'
                except ValueError:
                    continue
                if adjusted in gt_addrs_set:
                    matches += 1
            if matches >= 3:
                return offset
        return None

    tasks = []
    for binary_key, funcs in decompiled.items():
        # Find matching GT binary key
        gt_bk = None
        if binary_key in gt_by_binary:
            gt_bk = binary_key
        else:
            # Try fuzzy match by package prefix
            for candidate in gt_by_binary:
                if binary_key.startswith(candidate.split('_')[0]) and binary_key.endswith(candidate.split('_')[-1]):
                    gt_bk = candidate
                    break
        if gt_bk is None:
            for addr in funcs:
                skipped_no_gt += 1
            continue

        # Detect base offset between Ghidra addresses and GT addresses
        gt_addr_set = set(gt_by_binary[gt_bk].keys())
        dec_addr_list = list(funcs.keys())
        base_offset = detect_base_offset(dec_addr_list, gt_addr_set)

        if base_offset is None:
            print(f"  WARNING: could not detect base offset for {binary_key}, trying offset=0")
            base_offset = 0

        if base_offset != 0:
            print(f"  {binary_key}: detected base offset 0x{base_offset:x}")

        for addr, func_info in funcs.items():
            try:
                adjusted = hex(int(addr, 16) - base_offset).lstrip('0x').lstrip('0') or '0'
            except ValueError:
                adjusted = addr.lower().lstrip('0') or '0'

            gt_name = gt_by_binary[gt_bk].get(adjusted)
            if gt_name is None:
                skipped_no_gt += 1
                continue
            if gt_name in skip_names or gt_name.startswith('_'):
                skipped_trivial += 1
                continue
            code = func_info.get("decompiled", "")
            if not code or len(code) < 10:
                continue
            tasks.append((binary_key, addr, code, gt_name))
            total += 1

    if args.max_functions:
        tasks = tasks[:args.max_functions]
        total = len(tasks)

    print(f"\nWill predict {total} functions (skipped {skipped_no_gt} no-GT, {skipped_trivial} trivial)")
    print(f"Starting inference...\n")

    start_time = time.time()

    for i, (binary_key, addr, code, gt_name) in enumerate(tasks):
        prompt = build_prompt(code, few_shot=args.few_shot)
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=4096)
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=30,
                temperature=0.1,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id,
            )

        new_tokens = outputs[0][inputs['input_ids'].shape[1]:]
        generated = tokenizer.decode(new_tokens, skip_special_tokens=True)
        predicted_name = extract_prediction(generated)

        if binary_key not in predictions:
            predictions[binary_key] = {}

        predictions[binary_key][addr] = {
            "predicted": predicted_name,
            "ground_truth": gt_name,
            "raw_output": generated[:200]
        }
        matched += 1

        if (i + 1) % 10 == 0 or i == 0:
            elapsed = time.time() - start_time
            rate = (i + 1) / elapsed
            eta = (total - i - 1) / rate if rate > 0 else 0
            print(f"  [{i+1}/{total}] {binary_key}/{addr}: "
                  f"pred='{predicted_name}' gt='{gt_name}' "
                  f"({rate:.1f} func/s, ETA {eta/60:.0f}min)")

    elapsed = time.time() - start_time

    output = {
        "metadata": {
            "model": args.model,
            "few_shot": args.few_shot,
            "total_functions": total,
            "matched_functions": matched,
            "elapsed_seconds": round(elapsed, 1),
            "functions_per_second": round(matched / elapsed, 2) if elapsed > 0 else 0
        },
        "predictions": predictions
    }

    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\nDone! {matched} predictions in {elapsed:.0f}s ({matched/elapsed:.1f} func/s)")
    print(f"Saved to {args.output}")


if __name__ == "__main__":
    main()
