#!/usr/bin/env python3
"""
Batch decompile stripped binaries with Ghidra headless on Wulver.
Adapted for Wulver directory structure.

Usage (called by run_ghidra.sbatch):
    python3 ghidra_decompile.py
    python3 ghidra_decompile.py --max-binaries 5   # test with 5 first
"""
import os
import sys
import subprocess
import json
import argparse
import time

# ============ Wulver paths ============
GHIDRA_HOME    = os.path.expanduser("~/starcoder_eval_v2/ghidra")
BINARIES_DIR   = os.path.expanduser("~/starcoder_eval_v2/repo/data/cross_project/stripped")
OUTPUT_DIR     = os.path.expanduser("~/starcoder_eval_v2/decompiled")
SCRIPT_DIR     = os.path.expanduser("~/starcoder_eval_v2/scripts")
# ======================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ghidra", default=GHIDRA_HOME)
    parser.add_argument("--binaries", default=BINARIES_DIR)
    parser.add_argument("--output", default=OUTPUT_DIR)
    parser.add_argument("--max-binaries", type=int, default=None,
                        help="Limit number of binaries (for testing)")
    parser.add_argument("--timeout", type=int, default=600,
                        help="Per-binary timeout in seconds (default 600)")
    args = parser.parse_args()

    analyze_headless = os.path.join(args.ghidra, "support", "analyzeHeadless")
    if not os.path.exists(analyze_headless):
        print(f"ERROR: analyzeHeadless not found at {analyze_headless}")
        sys.exit(1)

    os.makedirs(args.output, exist_ok=True)
    os.makedirs(SCRIPT_DIR, exist_ok=True)

    # Copy the Ghidra Jython export script to scripts dir
    export_script_src = os.path.join(os.path.dirname(__file__), "ghidra_export.py")
    export_script_dst = os.path.join(SCRIPT_DIR, "ghidra_export.py")
    if os.path.exists(export_script_src):
        import shutil
        if os.path.abspath(export_script_src) != os.path.abspath(export_script_dst): shutil.copy2(export_script_src, export_script_dst)
    elif not os.path.exists(export_script_dst):
        print(f"ERROR: ghidra_export.py not found at {export_script_src}")
        sys.exit(1)

    # Ghidra project directory (temp, per-binary, auto-deleted)
    project_dir = os.path.join("/tmp", f"ghidra_projects_{os.getpid()}")
    os.makedirs(project_dir, exist_ok=True)

    # Get all binary files
    binaries = sorted([f for f in os.listdir(args.binaries)
                       if os.path.isfile(os.path.join(args.binaries, f))
                       and not f.startswith('.')])

    if args.max_binaries:
        binaries = binaries[:args.max_binaries]

    print(f"Found {len(binaries)} binaries to decompile")
    print(f"Ghidra: {analyze_headless}")
    print(f"Output: {args.output}")
    print(f"Timeout per binary: {args.timeout}s")
    print()

    t0 = time.time()
    done = 0
    skipped = 0
    failed = 0

    for i, binary in enumerate(binaries):
        binary_path = os.path.join(args.binaries, binary)
        output_file = os.path.join(args.output, binary + ".json")

        # Skip if already decompiled
        if os.path.exists(output_file):
            size = os.path.getsize(output_file)
            if size > 10:  # not empty
                print(f"[{i+1}/{len(binaries)}] SKIP {binary} (already done, {size} bytes)")
                skipped += 1
                continue

        print(f"[{i+1}/{len(binaries)}] Decompiling {binary}...")
        bt = time.time()

        env = os.environ.copy()

        cmd = [
            analyze_headless,
            project_dir, f"proj_{binary}",
            "-import", binary_path,
            "-postScript", "ghidra_export.py", args.output,
            "-scriptPath", SCRIPT_DIR,
            "-deleteProject",
        ]

        try:
            result = subprocess.run(
                cmd, env=env, capture_output=True, text=True,
                timeout=args.timeout
            )
            elapsed_b = time.time() - bt

            if os.path.exists(output_file) and os.path.getsize(output_file) > 10:
                print(f"  OK in {elapsed_b:.0f}s")
                done += 1
            else:
                print(f"  WARNING: no output produced (return code {result.returncode})")
                if result.stderr:
                    # Print last 300 chars of stderr for debugging
                    print(f"  stderr: ...{result.stderr[-300:]}")
                failed += 1

        except subprocess.TimeoutExpired:
            print(f"  TIMEOUT after {args.timeout}s, skipping")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {e}")
            failed += 1

    elapsed_total = time.time() - t0
    print()
    print("=" * 60)
    print(f"DONE in {elapsed_total:.0f}s ({elapsed_total/60:.1f} min)")
    print(f"  Decompiled: {done}")
    print(f"  Skipped:    {skipped}")
    print(f"  Failed:     {failed}")
    print(f"  Total:      {done + skipped + failed} / {len(binaries)}")

    # List output files
    json_files = [f for f in os.listdir(args.output) if f.endswith('.json')]
    print(f"  Output JSONs: {len(json_files)}")
    print("=" * 60)

if __name__ == "__main__":
    main()
