# Ghidra Jython script (runs inside Ghidra's Jython 2.7)
# This is a POST-ANALYSIS script invoked by analyzeHeadless.
# It decompiles every non-thunk, non-external function and writes
# a single JSON file per binary: { "addr": {"name": ..., "decompiled": ...}, ... }

from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
import json
import os

output_dir = getScriptArgs()[0] if len(getScriptArgs()) > 0 else "/tmp/decompiled"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

program = getCurrentProgram()
binary_name = program.getName()

decomp = DecompInterface()
decomp.openProgram(program)
monitor = ConsoleTaskMonitor()

result = {}
count = 0

for func in program.getFunctionManager().getFunctions(True):
    if func.isThunk() or func.isExternal():
        continue
    try:
        res = decomp.decompileFunction(func, 30, monitor)
        if res and res.getDecompiledFunction():
            code = res.getDecompiledFunction().getC()
            addr = func.getEntryPoint().toString().lower()
            result[addr] = {"name": func.getName(), "decompiled": code}
            count += 1
    except:
        pass

output_file = os.path.join(output_dir, binary_name + ".json")
f = open(output_file, "w")
f.write(json.dumps(result, indent=2))
f.close()
print("Decompiled %d functions from %s" % (count, binary_name))
