#!/usr/bin/env python3
"""
Evaluate LLM baseline predictions using subtoken F1 and exact match metrics.
Compatible with the project's evaluation methodology.

Usage:
    python3 evaluate_llm.py --predictions ~/llm_baseline/predictions.json
"""
import json
import re
import argparse
from collections import defaultdict


def split_name_to_subtokens(name: str) -> list:
    """Split a function name into subtokens by underscore and camelCase."""
    # First split by underscore
    parts = name.split('_')
    
    subtokens = []
    for part in parts:
        if not part:
            continue
        # Split camelCase: insertBefore -> [insert, Before]
        camel_split = re.sub(r'([a-z])([A-Z])', r'\1_\2', part).split('_')
        for token in camel_split:
            token = token.lower().strip()
            if token:
                subtokens.append(token)
    
    return subtokens


def compute_subtoken_metrics(pred_name: str, gt_name: str) -> dict:
    """Compute subtoken precision, recall, F1 for a single prediction."""
    pred_tokens = split_name_to_subtokens(pred_name)
    gt_tokens = split_name_to_subtokens(gt_name)
    
    if not pred_tokens and not gt_tokens:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0}
    if not pred_tokens or not gt_tokens:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}
    
    # Count token overlap (multiset intersection)
    pred_counts = defaultdict(int)
    gt_counts = defaultdict(int)
    for t in pred_tokens:
        pred_counts[t] += 1
    for t in gt_tokens:
        gt_counts[t] += 1
    
    overlap = 0
    for token in pred_counts:
        if token in gt_counts:
            overlap += min(pred_counts[token], gt_counts[token])
    
    precision = overlap / len(pred_tokens) if pred_tokens else 0.0
    recall = overlap / len(gt_tokens) if gt_tokens else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {"precision": precision, "recall": recall, "f1": f1}


def main():
    parser = argparse.ArgumentParser(description="Evaluate LLM baseline predictions")
    parser.add_argument("--predictions", required=True, help="Path to predictions.json")
    parser.add_argument("--detailed", action="store_true", help="Print per-function details")
    args = parser.parse_args()
    
    with open(args.predictions) as f:
        data = json.load(f)
    
    metadata = data.get("metadata", {})
    predictions = data.get("predictions", {})
    
    print("=" * 70)
    print("LLM Baseline Evaluation Results")
    print("=" * 70)
    print(f"Model: {metadata.get('model', 'unknown')}")
    print(f"Few-shot: {metadata.get('few_shot', 'unknown')}")
    print(f"Total functions: {metadata.get('total_functions', 'unknown')}")
    print(f"Inference time: {metadata.get('elapsed_seconds', 0):.0f}s")
    print()
    
    # Compute metrics
    all_metrics = []
    exact_matches = 0
    total = 0
    per_binary = defaultdict(list)
    
    errors = []  # For error analysis
    
    for binary_key, funcs in predictions.items():
        for addr, info in funcs.items():
            pred = info["predicted"]
            gt = info["ground_truth"]
            
            metrics = compute_subtoken_metrics(pred, gt)
            all_metrics.append(metrics)
            per_binary[binary_key].append(metrics)
            
            exact = (pred.lower() == gt.lower())
            if exact:
                exact_matches += 1
            
            total += 1
            
            if metrics["f1"] < 0.5:
                errors.append({
                    "binary": binary_key,
                    "addr": addr,
                    "predicted": pred,
                    "ground_truth": gt,
                    "f1": metrics["f1"],
                    "pred_tokens": split_name_to_subtokens(pred),
                    "gt_tokens": split_name_to_subtokens(gt),
                })
            
            if args.detailed:
                marker = "✓" if exact else ("~" if metrics["f1"] > 0 else "✗")
                print(f"  {marker} [{binary_key}] {addr}: pred='{pred}' gt='{gt}' F1={metrics['f1']:.2f}")
    
    if total == 0:
        print("No predictions found!")
        return
    
    # Aggregate metrics
    avg_precision = sum(m["precision"] for m in all_metrics) / total
    avg_recall = sum(m["recall"] for m in all_metrics) / total
    avg_f1 = sum(m["f1"] for m in all_metrics) / total
    exact_match_rate = exact_matches / total
    
    print("-" * 70)
    print("AGGREGATE METRICS")
    print("-" * 70)
    print(f"  Subtoken Precision:  {avg_precision:.4f}  ({avg_precision*100:.1f}%)")
    print(f"  Subtoken Recall:     {avg_recall:.4f}  ({avg_recall*100:.1f}%)")
    print(f"  Subtoken F1:         {avg_f1:.4f}  ({avg_f1*100:.1f}%)")
    print(f"  Exact Match (Top-1): {exact_match_rate:.4f}  ({exact_match_rate*100:.1f}%)")
    print(f"  Total Functions:     {total}")
    print()
    
    # Per-binary breakdown
    print("-" * 70)
    print("PER-BINARY BREAKDOWN")
    print("-" * 70)
    print(f"  {'Binary':<40} {'#Funcs':>6} {'P':>7} {'R':>7} {'F1':>7}")
    print(f"  {'-'*40} {'-'*6} {'-'*7} {'-'*7} {'-'*7}")
    
    for binary_key in sorted(per_binary.keys()):
        bm = per_binary[binary_key]
        n = len(bm)
        bp = sum(m["precision"] for m in bm) / n
        br = sum(m["recall"] for m in bm) / n
        bf = sum(m["f1"] for m in bm) / n
        print(f"  {binary_key:<40} {n:>6} {bp:>7.3f} {br:>7.3f} {bf:>7.3f}")
    
    # Error analysis
    print()
    print("-" * 70)
    print("ERROR ANALYSIS (worst predictions, F1 < 0.5)")
    print("-" * 70)
    errors.sort(key=lambda x: x["f1"])
    for err in errors[:20]:
        print(f"  [{err['binary']}] pred='{err['predicted']}' gt='{err['ground_truth']}' "
              f"F1={err['f1']:.2f}")
        print(f"    pred_tokens={err['pred_tokens']}")
        print(f"    gt_tokens={err['gt_tokens']}")
    
    if len(errors) > 20:
        print(f"  ... and {len(errors) - 20} more errors")
    
    # Summary for report table
    print()
    print("=" * 70)
    print("FOR REPORT TABLE (copy-paste ready)")
    print("=" * 70)
    print(f"| LLM Zero-Shot (StarCoder-3B) | {avg_precision:.3f} | {avg_recall:.3f} | {avg_f1:.3f} | {exact_match_rate*100:.1f}% |")
    print("=" * 70)
    
    # Save detailed results
    results_path = args.predictions.replace(".json", "_eval.json")
    eval_output = {
        "aggregate": {
            "subtoken_precision": round(avg_precision, 4),
            "subtoken_recall": round(avg_recall, 4),
            "subtoken_f1": round(avg_f1, 4),
            "exact_match_top1": round(exact_match_rate, 4),
            "total_functions": total
        },
        "per_binary": {
            k: {
                "num_functions": len(v),
                "precision": round(sum(m["precision"] for m in v) / len(v), 4),
                "recall": round(sum(m["recall"] for m in v) / len(v), 4),
                "f1": round(sum(m["f1"] for m in v) / len(v), 4)
            }
            for k, v in per_binary.items()
        }
    }
    with open(results_path, "w") as f:
        json.dump(eval_output, f, indent=2)
    print(f"\nDetailed results saved to {results_path}")


if __name__ == "__main__":
    main()
